// Main JavaScript for TechElbay Portfolio

document.addEventListener('DOMContentLoaded', function() {
    // Navigation menu toggle for mobile
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
      if (hamburger) {
        hamburger.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            this.setAttribute('aria-expanded', !isExpanded);
            this.classList.toggle('active');
            navLinks.classList.toggle('active');
        });
    }
    
    // Close mobile menu when clicking on a nav link
    const navItems = document.querySelectorAll('.nav-links a');
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            hamburger.classList.remove('active');
            navLinks.classList.remove('active');
        });
    });
    
    // Header scroll effect
    const header = document.querySelector('header');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Back to top button
    const backToTopBtn = document.querySelector('.back-to-top');
    window.addEventListener('scroll', function() {
        if (window.scrollY > 300) {
            backToTopBtn.classList.add('active');
        } else {
            backToTopBtn.classList.remove('active');
        }
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Project filtering
    const filterBtns = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
      filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Update aria-pressed state and active class
            filterBtns.forEach(btn => {
                btn.setAttribute('aria-pressed', 'false');
                btn.classList.remove('active');
            });
            this.setAttribute('aria-pressed', 'true');
            this.classList.add('active');
            
            const filterValue = this.getAttribute('data-filter');
            
            projectCards.forEach(card => {
                if (filterValue === 'all' || card.getAttribute('data-category') === filterValue) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
      // Add keyboard navigation to project cards
    const projectCards = document.querySelectorAll('.project-card');
    projectCards.forEach(card => {
        // Make project cards focusable
        card.setAttribute('tabindex', '0');
        
        // Handle keyboard events
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const demoLink = this.querySelector('.demo-link');
                if (demoLink) {
                    demoLink.click();
                }
            }
        });
    });    // Project demo modal
    const demoLinks = document.querySelectorAll('.demo-link');
    const modal = document.getElementById('demoModal');
    const closeModal = document.querySelector('.close-modal');
    const demoFrames = document.querySelectorAll('.demo-frame');
    let lastFocusedElement = null;
    
    function openModal(demoId) {
        lastFocusedElement = document.activeElement;
        
        // Hide all demo frames
        demoFrames.forEach(frame => {
            frame.style.display = 'none';
            frame.setAttribute('hidden', '');
        });
        
        // Show the selected demo frame
        const selectedDemo = document.getElementById(demoId);
        if (selectedDemo) {
            selectedDemo.style.display = 'block';
            selectedDemo.removeAttribute('hidden');
        }
        
        // Show the modal
        modal.removeAttribute('hidden');
        document.body.style.overflow = 'hidden';
        
        // Focus the close button
        closeModal.focus();
    }
    
    function closeModalHandler() {
        modal.setAttribute('hidden', '');
        document.body.style.overflow = 'auto';
        
        // Return focus to the trigger element
        if (lastFocusedElement) {
            lastFocusedElement.focus();
        }
    }
    
    demoLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const demoId = this.getAttribute('data-demo');
            openModal(demoId);
        });
    });
    
    // Handle modal keyboard interactions
    modal.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeModalHandler();
        }
    });
      if (closeModal) {
        closeModal.addEventListener('click', closeModalHandler);
    }
    
    // Close modal when clicking outside the content
    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModalHandler();
        }
    });
    
    // Trap focus within modal when it's open
    modal.addEventListener('keydown', function(e) {
        if (e.key !== 'Tab') return;
        
        const focusableElements = modal.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];
        
        if (e.shiftKey) {
            if (document.activeElement === firstFocusable) {
                e.preventDefault();
                lastFocusable.focus();
            }
        } else {
            if (document.activeElement === lastFocusable) {
                e.preventDefault();
                firstFocusable.focus();
            }
        }
    });
      // Animate skill progress bars with counting effect
    function animateSkillBars() {
        const skillBars = document.querySelectorAll('.skill-progress');
        const duration = 1500; // Animation duration in milliseconds
        const frameRate = 1000 / 60; // 60fps
        
        skillBars.forEach(bar => {
            const progress = parseInt(bar.getAttribute('data-progress'));
            const parentSkill = bar.closest('.skill');
            const percentageSpan = parentSkill.querySelector('.skill-info span:last-child');
            let currentWidth = 0;
            let currentPercent = 0;
            const incrementWidth = progress / (duration / frameRate);
            const incrementPercent = progress / (duration / frameRate);
            
            // Reset initial state
            bar.style.width = '0%';
            percentageSpan.textContent = '0%';
            
            const animation = setInterval(() => {
                currentWidth += incrementWidth;
                currentPercent += incrementPercent;
                
                // Update progress bar width
                bar.style.width = Math.min(currentWidth, progress) + '%';
                
                // Update percentage text with smooth counting
                percentageSpan.textContent = Math.min(Math.round(currentPercent), progress) + '%';
                
                // Add transition class for smooth color change
                bar.classList.add('animating');
                
                if (currentWidth >= progress) {
                    clearInterval(animation);
                    // Add completed class for final state
                    bar.classList.add('completed');
                }
            }, frameRate);
        });
    }
    
    // Check if element is in viewport
    function isInViewport(element) {
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
    
    // Animate skill bars when skills section is in viewport
    const skillsSection = document.querySelector('#skills');
    let animated = false;
    
    function checkSkillsVisibility() {
        if (skillsSection && isInViewport(skillsSection) && !animated) {
            animateSkillBars();
            animated = true;
        }
    }
    
    // Check on scroll
    window.addEventListener('scroll', checkSkillsVisibility);
    // Check on page load
    window.addEventListener('load', checkSkillsVisibility);
    
    // Form submission handling
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const name = document.getElementById('name').value;
            const email = document.getElementById('email').value;
            const subject = document.getElementById('subject').value;
            const message = document.getElementById('message').value;
            
            // Here you would typically send the data to a server
            // For this demo, we'll just show an alert
            alert(`Thank you for your message, ${name}! I'll get back to you soon.`);
            
            // Reset the form
            contactForm.reset();
        });
    }
    
    // Newsletter form handling
    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get email
            const email = this.querySelector('input[type="email"]').value;
            
            // Here you would typically send the data to a server
            // For this demo, we'll just show an alert
            alert(`Thank you for subscribing with ${email}! You'll receive updates on my latest projects.`);
            
            // Reset the form
            newsletterForm.reset();
        });
    }
});
